module.exports = {
  less: {
	  files: ['src/css/less/*.less'],
	  tasks: ['recess'],
  }
}
